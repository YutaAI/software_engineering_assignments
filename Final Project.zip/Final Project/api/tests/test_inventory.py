from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from ..models import sandwiches as sandwich_model
from ..models import resources as resource_model
from ..models import recipes as recipe_model
from ..models import orders as order_model
from ..dependencies.database import Base
from ..controllers import orders as orders_controller
from ..controllers import order_details as order_details_controller
from ..schemas import orders as order_schemas
from ..schemas import order_details as order_details_schemas


def test_inventory_decrements_on_orderdetail_create():
    # setup in-memory sqlite
    engine = create_engine("sqlite:///:memory:")
    TestingSessionLocal = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)

    db = TestingSessionLocal()

    # create a resource with amount 10
    resource = resource_model.Resource(item="Cheese", amount=10)
    db.add(resource)
    db.commit()
    db.refresh(resource)

    # create a sandwich
    sandwich = sandwich_model.Sandwich(sandwich_name="Cheesy", price=5.0)
    db.add(sandwich)
    db.commit()
    db.refresh(sandwich)

    # create a recipe: requires 2 units of Cheese per sandwich
    recipe = recipe_model.Recipe(sandwich_id=sandwich.id, resource_id=resource.id, amount=2)
    db.add(recipe)
    db.commit()

    # create an order
    order_req = order_schemas.OrderCreate(customer_name="Tester", description="inv test")
    created_order = orders_controller.create(db=db, request=order_req)

    # create an order detail for 3 sandwiches -> requires 6 units
    od_req = order_details_schemas.OrderDetailCreate(order_id=created_order.id, sandwich_id=sandwich.id, amount=3)
    created_od = order_details_controller.create(db=db, request=od_req)

    # refresh resource and assert amount decreased to 4
    db.refresh(resource)
    assert resource.amount == 4

    db.close()
