from fastapi.testclient import TestClient
from ..main import app
from ..models import feedbacks as model

client = TestClient(app)


def test_feedbacks_route_registered():
    """Test that feedbacks route is registered."""
    paths = set(app.openapi()["paths"].keys())
    assert "/feedbacks/" in paths


def test_create_feedback_model():
    """Test feedback model instantiation."""
    data = {
        "order_id": 1,
        "customer_name": "John Doe",
        "rating": 5,
        "comment": "Excellent service!"
    }
    feedback = model.Feedback(**data)
    assert feedback.order_id == 1
    assert feedback.customer_name == "John Doe"
    assert feedback.rating == 5
    assert feedback.comment == "Excellent service!"
