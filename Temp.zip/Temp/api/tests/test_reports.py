from fastapi.testclient import TestClient
from ..main import app

client = TestClient(app)


def test_reports_route_registered():
    """Test that reports routes are registered."""
    paths = set(app.openapi()["paths"].keys())
    assert "/reports/summary" in paths or "/reports/orders_by_status" in paths


def test_reports_endpoints_exist():
    """Test that report endpoints exist."""
    paths = set(app.openapi()["paths"].keys())
    # At least one of the report endpoints should be registered
    assert len([p for p in paths if p.startswith("/reports/")]) > 0
