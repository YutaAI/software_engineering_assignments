from fastapi.testclient import TestClient
from ..main import app
from ..models import payments as model

client = TestClient(app)


def test_payments_route_registered():
    """Test that payments route is registered."""
    paths = set(app.openapi()["paths"].keys())
    assert "/payments/" in paths


def test_create_payment_model():
    """Test payment model instantiation."""
    data = {
        "order_id": 1,
        "amount": 25.99,
        "method": "credit_card",
        "status": "completed"
    }
    payment = model.Payment(**data)
    assert payment.order_id == 1
    assert payment.amount == 25.99
    assert payment.method == "credit_card"
    assert payment.status == "completed"
