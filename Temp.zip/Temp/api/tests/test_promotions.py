from fastapi.testclient import TestClient
from ..main import app
from ..models import promotions as model

client = TestClient(app)


def test_promotions_route_registered():
    """Test that promotions route is registered."""
    paths = set(app.openapi()["paths"].keys())
    assert "/promotions/" in paths


def test_create_promotion_model():
    """Test promotion model instantiation."""
    data = {
        "promo_code": "SUMMER2026",
        "description": "Summer discount",
        "discount_percentage": 15,
        "active": True
    }
    promo = model.Promotion(**data)
    assert promo.promo_code == "SUMMER2026"
    assert promo.discount_percentage == 15
    assert promo.active is True
